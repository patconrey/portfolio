Hi!

Thanks for checking out this experiment.

To play through the experiment, load the script "play_experiment.m" in Matlab.
Follow the prompts shown in the command line.

Thanks!