function [] = print_instructions()
disp('INSTRUCTIONS');
disp('You will be presented with 5 experiment sets. Each set will contain 4 speech samples.'); 
disp('Some of the speech comes from real speakers. Some of the speech is spoofed.');
disp('Within each set, there is one speech sample that is unlike the others.');
disp('Your job is to guess what it is.');
disp(' ');
end

